#!/bin/bash
cd wallet/
rm * -R
