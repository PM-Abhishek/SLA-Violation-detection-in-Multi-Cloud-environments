/*
 * SPDX-License-Identifier: Apache-2.0
 */

'use strict';

const LogChain = require('./lib/logchain');

module.exports.LogChain= LogChain;
module.exports.contracts = [ LogChain ];
