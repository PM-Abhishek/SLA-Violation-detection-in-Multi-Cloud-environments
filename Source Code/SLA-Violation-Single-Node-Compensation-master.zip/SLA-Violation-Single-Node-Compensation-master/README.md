# SLA-Violation-Single-Node-Compensation
Sla violation single node with no database, No bin folder included, No node modules included

copy bin folder from fabric sample to SLA-Violaton-Single-Node folder

cd chaincode/logchain/javascript npm install

cd HLF_logs/javascript npm install

cd HLF_logs/javascript/Frontend npm install

./bootscript.sh

cd HLF_logs/javascript node server.js

cd HLF_logs/javascript/Frontend npm start
